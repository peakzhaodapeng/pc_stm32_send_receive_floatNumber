﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO.Ports;//得有这个文件才能支持串口

namespace RXTX_protocalCheck
{
    public partial class Form1 : Form
    {
        private SerialPort serialPort2;
        public Form1()
        {
            InitializeComponent();
            serialPort2 = new SerialPort();
            
        }
        //public SerialPort serialPort1;
       
        public static Byte[] datafresh = new Byte[4];//定义一个4个字节的数组，为了能让所有的函数都能使用，前面加了public和static，而且这也是一个实例
        public static Byte[] datafresh1 = new Byte[4];
        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {

                //* Byte数组的个数是不确定的，根据实时返回的指令个数为准,而且返回的都是10进制数
                do
                {
                    //serialPort.ReadBufferSize();
                    int count = serialPort2.BytesToRead;  // 串口的接收缓冲区，
                    if (count <= 0)   //count <= 0 ：表示没有接收到指令
                        break;
                    Byte[] dataBuff = new Byte[count];

                    if (count == 4)//加了一个保护再也不会出问题了，不到20个字节直接不处理，这样就避免了 datafresh[inter_cnt] = dataBuff[inter_cnt + 2];读数据的时候数组里面就没这么多
                    {
                        serialPort2.Read(dataBuff, 0, count);  //串口读取接收缓存区的数据


                        for (int inter_cnt = 0; inter_cnt < 4; inter_cnt++)
                        {
                            datafresh[inter_cnt] = dataBuff[inter_cnt];//如果这一句加上就会出错误：未将对象引用设置到对象的实例
                        }


                        textBox2.Text = BitConverter.ToSingle(datafresh, 0).ToString();//对于dataBuff数组从第二个元素开始检索。


                    }
                    else if (count == 8)//加了一个保护再也不会出问题了，不到20个字节直接不处理，这样就避免了 datafresh[inter_cnt] = dataBuff[inter_cnt + 2];读数据的时候数组里面就没这么多
                    {
                        serialPort2.Read(dataBuff, 0, count);  //串口读取接收缓存区的数据


                        for (int inter_cnt = 0; inter_cnt < 4; inter_cnt++)
                        {
                            datafresh[inter_cnt] = dataBuff[inter_cnt];//如果这一句加上就会出错误：未将对象引用设置到对象的实例
                        }
                        for (int inter_cnt_distacne = 0; inter_cnt_distacne < 4; inter_cnt_distacne++)
                        {
                            datafresh1[inter_cnt_distacne] = dataBuff[inter_cnt_distacne + 4];//如果这一句加上就会出错误：未将对象引用设置到对象的实例
                        }


                        textBox5.Text = BitConverter.ToSingle(datafresh, 0).ToString();//对于dataBuff数组从第二个元素开始检索。
                        textBox6.Text = BitConverter.ToSingle(datafresh1, 0).ToString();//对于dataBuff数组从第二个数组开始检索。


                    }

                    // serialPort.DiscardInBuffer();//丢弃串口缓冲区中的内容
                } while (serialPort2.BytesToRead > 0);//这里仅仅是保证>0就可以，但是我需要的可是八个字节

            }
            catch (Exception ex)
            {
                MessageBox.Show("error:接收返回信息异常：" + ex.Message);
            }
            
        }

        private void sendOneBytebutton1_Click(object sender, EventArgs e)
        {
            float kp1;
           
            try
            {
               // serialPort.ReceivedBytesThreshold = 4; //获取或设置 System.IO.Ports.SerialPort.DataReceived 事件发生前内部输入缓冲区中的字节数，达到这个字节数会触发中断。
                kp1 = Convert.ToSingle(textBox1.Text);//文本转单精度浮点数
                byte[] kp1_arr = BitConverter.GetBytes(kp1);//浮点模式转小端模式数组
                
                byte[] sendbuffer = new byte[9] { 0xa5, 0x5a, 0x01, 0x00, 0x00, 0x00, 0x00 ,0x00,0x00};
                kp1_arr.CopyTo(sendbuffer, 3);//发送数组装载数值
                byte CRC_L, CRC_H;
                byte Carry, n;
                byte i = 0;
                int sendbuf_length = sendbuffer.Length - 2;
                CRC_L = 0xff;
                CRC_H = 0xff;
                while (sendbuf_length > 0)
                {
                    CRC_L = (byte)(CRC_L ^ (sendbuffer[i]));
                    for (n = 0; n < 8; n++)
                    {
                        Carry = (byte)(CRC_L & 1);
                        CRC_L >>= 1;

                        if ((CRC_H & 0x01) != 0)
                            CRC_L = (byte)(CRC_L | 0x80);
                        CRC_H >>= 1;
                        if (Carry != 0)
                        {
                            CRC_L ^= 0x01;
                            CRC_H ^= 0xa0;
                        }
                    }
                    i++;
                    sendbuf_length--;
                }
                sendbuffer[sendbuffer.Length - 2] = CRC_L;
                sendbuffer[sendbuffer.Length - 1] = CRC_H;
                serialPort2.Write(sendbuffer, 0, sendbuffer.Length);


            }
            catch
            {
                MessageBox.Show("发送失败");
            }
        }

        private void sendTwoBytesbutton2_Click(object sender, EventArgs e)
        {
            float kp2, ki2;

            try
            {
                //获取或设置 System.IO.Ports.SerialPort.DataReceived 事件发生前内部输入缓冲区中的字节数，达到这个字节数会触发中断。
                kp2 = Convert.ToSingle(textBox3.Text);//文本转单精度浮点数
                ki2 = Convert.ToSingle(textBox4.Text);//文本转单精度浮点数
                byte[] kp2_arr = BitConverter.GetBytes(kp2);//浮点模式转小端模式数组
                byte[] ki2_arr = BitConverter.GetBytes(ki2);//浮点模式转小端模式数组

                byte[] sendbuffer = new byte[13] { 0xa5, 0x5a, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
                kp2_arr.CopyTo(sendbuffer, 3);//发送数组装载数值
                ki2_arr.CopyTo(sendbuffer, 7);//发送数组装载数值

                byte CRC_L, CRC_H;
                byte Carry, n;
                byte i = 0;
                int sendbuf_length = sendbuffer.Length - 2;
                CRC_L = 0xff;
                CRC_H = 0xff;
                while (sendbuf_length > 0)
                {
                    CRC_L = (byte)(CRC_L ^ (sendbuffer[i]));
                    for (n = 0; n < 8; n++)
                    {
                        Carry = (byte)(CRC_L & 1);
                        CRC_L >>= 1;

                        if ((CRC_H & 0x01) != 0)
                            CRC_L = (byte)(CRC_L | 0x80);
                        CRC_H >>= 1;
                        if (Carry != 0)
                        {
                            CRC_L ^= 0x01;
                            CRC_H ^= 0xa0;
                        }
                    }
                    i++;
                    sendbuf_length--;
                }
                sendbuffer[sendbuffer.Length - 2] = CRC_L;
                sendbuffer[sendbuffer.Length - 1] = CRC_H;
                serialPort2.Write(sendbuffer, 0, sendbuffer.Length);


            }
            catch
            {
                MessageBox.Show("发送失败");
            }
        }

        private void search_button3_Click(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            string[] ArrComPortsName = SerialPort.GetPortNames();//获取当前串口个数名称
            if (ArrComPortsName.Length != 0)
            {
                Array.Sort(ArrComPortsName);
            }
            for (int portNUM_cnt = 0; portNUM_cnt < ArrComPortsName.Length; portNUM_cnt++)
            {
                comboBox1.Items.Add(ArrComPortsName[portNUM_cnt]);
            }
            comboBox1.Text = ArrComPortsName[0];
        }

        private void open_port_button4_Click(object sender, EventArgs e)
        {
            serialPort2.Close();
            try
            {
                serialPort2.PortName = comboBox1.Text;
                serialPort2.BaudRate = 115200;  //转换为10进制
                serialPort2.DataBits = 8;
                serialPort2.StopBits = (StopBits)1;
                serialPort2.Open();
                label8.BackColor = System.Drawing.Color.GreenYellow;
                /*工作模式和配置模式下ReceivedBytesThreshold是不一样的，接收长度是不一样的*/
                serialPort2.ReceivedBytesThreshold = 4; 
                serialPort2.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived); //串口接收指令事件

            }
            catch
            {
                MessageBox.Show("串口设置错误");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            serialPort2.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label8.BackColor = System.Drawing.Color.Transparent;
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;//禁用了所有的控件合法性检查
        }

        private void button5_Click(object sender, EventArgs e)
        {
            serialPort2.Close();
            try
            {
                serialPort2.PortName = comboBox1.Text;
                serialPort2.BaudRate = 115200;  //转换为10进制
                serialPort2.DataBits = 8;
                serialPort2.StopBits = (StopBits)1;
                serialPort2.Open();
                label8.BackColor = System.Drawing.Color.GreenYellow;
                /*工作模式和配置模式下ReceivedBytesThreshold是不一样的，接收长度是不一样的*/
                serialPort2.ReceivedBytesThreshold = 8;
                serialPort2.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived); //串口接收指令事件

            }
            catch
            {
                MessageBox.Show("串口设置错误");
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //textBox2.Text = BitConverter.ToSingle(datafresh, 0).ToString();//对于dataBuff数组从第二个元素开始检索。
        }
    }
}
